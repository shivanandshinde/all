/*
Program No.1:-Matrix multiplication using strassen's algorithm of n by n order (RECURSIVE)
Name:-Roshan Jha
*/


#include<stdio.h>
int n;
void strassen(int a[][n], int b[][n], int c[][n], int size) 
{
int p1[size/2][size/2], p2[size/2][size/2], p3[size/2][size/2], p4[size/2][size/2], p5[size/2][size/2], p6[size/2][size/2], p7[size/2][size/2];
int temp1[size/2][size/2], temp2[size/2][size/2];
int  i, j;

//As in Strassan's matrix the order of matrix should be power of 2

if(size >=2)
{
	//To calculate part1 i.e. p1=(A11+A22)*(B11+B22)
        for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
	  	temp1[i][j]=a[i][j]+a[i+size/2][j+size/2]; //half sub part of p1
		}
	}
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp2[i][j]=b[i][j]+b[i+size/2][j+size/2];//Second sub part of p1
		}
	}
n =size/2;
strassen(temp1, temp2, p1, n);	

	// To Calculate Part2 i.e. p2=(A21+A22)*B11
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp1[i][j]=a[i+size/2][j]+a[i+size/2][j+size/2];
		}
	}

	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp2[i][j]=b[i][j];
		}
	}
n =size/2;
strassen(temp1, temp2, p2, n);

	// To Calculate Part3 i.e. p3=A11*(B12-B22)
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp1[i][j]=a[i][j];
		}
	}
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp2[i][j]=b[i][j+size/2]-b[i+size/2][j+size/2];
		}
	}
n=size/2;
strassen(temp1, temp2, p3, n);

	// To Calculate Part4 i.e. p4=A22*(B21-B11)
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp1[i][j]=a[i+size/2][j+size/2];
		}
	}
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp2[i][j]=b[i+size/2][j]-b[i][j];
		}
	}
n=size/2;
strassen(temp1, temp2, p4, n);

	// To Calculate Part5 i.e. p5=(A11+A12)*B22
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp1[i][j]=a[i][j]+a[i][j+size/2];
		}
	}
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp2[i][j]=b[i+size/2][j+size/2];
		}
	}
n=size/2;
strassen(temp1, temp2, p5, n);

	// To Calculate Part6 i.e. p6=(A21-A11)*(B11+B12)
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp1[i][j]=a[i+size/2][j]-a[i][j];
		}
	}
	for(i=0;i<size/2;i++)	
	{
		for(j=0;j<size/2;j++)
		{
		temp2[i][j]=b[i][j]+b[i][j+size/2];
		}
	}
n=size/2;
strassen(temp1, temp2, p6, n);

	// To Calculate Part7 i.e. p7=(A12-A22)*(B21+B22)
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp1[i][j]=a[i][j+size/2]-a[i+size/2][j+size/2];
		}
	}
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		temp2[i][j]=b[i+size/2][j]+b[i+size/2][j+size/2];
		}
	}
n=size/2;
strassen(temp1, temp2, p7, n);

//these value p1.....p7 are put in to following formula to get actual result here as product in matrix c

//To Calculate C11=p1+p4-p5+p7
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		c[i][j] = p1[i][j] + p4[i][j] - p5[i][j] + p7[i][j];
		}
	}
	
//To Calculate C12=p3+p5
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		c[i][j+size/2] = p3[i][j] + p5[i][j];
	        }
        }

//To Calculate C21=p2+p4
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		c[i+size/2][j] = p2[i][j] + p4[i][j];
		}
	}

//To Calculate C22=p1+p3-p2+p6
	for(i=0;i<size/2;i++)
	{
		for(j=0;j<size/2;j++)
		{
		c[i+size/2][j+size/2] = p1[i][j] + p3[i][j] - p2[i][j] + p6[i][j];
		}
	}
}
else if(size==1)
{ 
	c[0][0]=a[0][0]*b[0][0];
}
}

int main() 
{
int i, j, temp;
printf("\nEnter the size of nxn matrix:");
scanf("%d", &n);
temp = n;
if(n <= 0)
return 0;

int a[n][n], b[n][n], c[n][n];
printf("\nEnter elements of Matrix A:"); //accept inputs for a and b from the user
for(i = 0; i < temp; i++) 
{
	for(j = 0; j < temp; j++) 
	{
	scanf("%d", &a[i][j]);
	}
}

printf("Matrix A:");
for(i = 0; i < n; i++)
{
        printf("\n");
	for(j = 0; j < n; j++) 
	{
	printf("\t%d ", a[i][j]);
	}
}
        printf("\n");

printf("\nEnter elements of Matrix B:");
for(i = 0; i < temp; i++)
{
	for(j = 0; j < temp; j++) 
	{
	scanf("%d", &b[i][j]);
  	}
}

printf("Matrix B:"); 
for(i = 0; i < n; i++)
{
        printf("\n");
	for(j = 0; j < n; j++) 
	{
	printf("\t%d ", b[i][j]);
	}
}
        printf("\n");

strassen(a, b, c, n);

printf("\nResultant Matrix after Multiplication of Matrix A and Matrix B is:\n");
for(i = 0; i < temp; i++)
{         
        printf("\n");
	for(j = 0; j < temp; j++) 
	{
	printf("\t%d ", c[i][j]);
	}
}
        printf("\n");

return 0;
}


/*
roshan@roshan:~/TE/DAA/Strassens$ gcc nbyn.c
roshan@roshan:~/TE/DAA/Strassens$ ./a.out

Enter the size of nxn matrix:4

Enter elements of Matrix A:1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 
Matrix A:
	1 	2 	3 	4 
	5 	6 	7 	8 
	9 	10 	11 	12 
	13 	14 	15 	16 

Enter elements of Matrix B:1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16
Matrix B:
	1 	2 	3 	4 
	5 	6 	7 	8 
	9 	10 	11 	12 
	13 	14 	15 	16 

Resultant Matrix after Multiplication of Matrix A and Matrix B is:

	90 	100 	110 	120 
	202 	228 	254 	280 
	314 	356 	398 	440 
	426 	484 	542 	600 
roshan@roshan:~/TE/DAA/Strassens$

*/
