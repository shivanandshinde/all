
#include<stdio.h>

void find_path(int x, int y);
void warshal(int cost_matrix[100][100],int d[100][100],int size);
void print(int mat[100][100],int size);
int path[100][100],src,dest;

void main()
{
int i, j, size, cost_matrix[100][100], d[100][100];
printf("\nEnter the number of vertices: ");
scanf("%d", &size);
printf("\n");
for(i=1; i<=size; i++)
  {
    for(j=1; j<=size; j++)
	{
	  if(i==j)
          {
	    cost_matrix[i][j]=0;
            printf("Distance Between node %d and node %d:0",i,j);	
            printf("\n");
          }
	  else
	    {
		printf("Enter the distance between node %d and node %d: ", i, j);
		scanf("%d", &cost_matrix[i][j]);
	    }
	 }
   }
        printf("\n"); 
	print(cost_matrix, size);	
	warshal(cost_matrix, d, size);
}

void warshal(int cost_matrix[100][100],int d[100][100], int size)
{
   int i, j, k,m,n,x,y,arr[10],ans;

	for(i=0; i<=size; i++)
	  for(j=0; j<size; j++)
	    path[i][j]=0;
			
          for(k=1;k<=size;k++)
 	      {
		for(i=1;i<=size;i++)
		   {
		     for(j=1;j<=size;j++)
		        {
			  if((cost_matrix[i][k]+cost_matrix[k][j])<cost_matrix[i][j])
			    {
			      d[i][j]=(cost_matrix[i][k]+cost_matrix[k][j]);
			      path[i][j]=k;
			    }
				else
				   d[i][j]=cost_matrix[i][j];	
			}
		    }
		
		for(m=1; m<=size; m++)
	           {
		     for(n=1; n<=size; n++)
		        {
			  cost_matrix[m][n]=d[m][n];	
		        }
	           }
		        
                        printf("\n Matrix D%d \n", k);
		        print(cost_matrix, size);
		}
	printf("\n"); 
	printf("\nPath matrix: \n");
	print(path, size);
	
	
		printf("\n\nEnter the Source node:");                             
		scanf("%d",&src);
                printf("\nEnter the Destination node:");
                scanf("%d",&dest);
		printf("The cost between %d and %d is %d and the path is:%d-",src,dest,cost_matrix[src][dest],src);
		find_path(src,dest);
                printf("\n");                                               //Data to find path matrix
}

void find_path(int x, int y)
{
	if(path[x][y]==0)
	  {
	    printf("%d-",y);
	    x=y;
	      if(x!=dest)
		 find_path(x,dest);
	  }

	else
	 {
	   y=path[x][y];
	      if(y!=0)
		find_path(x,y);
	 }
}

void print(int mat[100][100],int size)
{
	int i, j;
	printf("\t");
	
          for(i=1; i<=size; i++)
	     {
	        printf("(%d)", i);
		printf("\t");
	     }
	
	  for(i=1; i<=size; i++)
	     {
		printf("\n");
		printf("(%d)", i);

		  for(j=1; j<=size; j++)
		     {
			printf("\t");
			printf("%d", mat[i][j]);
	             }
	     }
}

/*
root@:~$ gcc fw.c
root@:~$ ./a.out

Enter the number of vertices: 3

Distance Between node 1 and node 1:0
Enter the distance between node 1 and node 2: 10
Enter the distance between node 1 and node 3: 9
Enter the distance between node 2 and node 1: 4
Distance Between node 2 and node 2:0
Enter the distance between node 2 and node 3: 999
Enter the distance between node 3 and node 1: 5
Enter the distance between node 3 and node 2: 999
Distance Between node 3 and node 3:0

	(1)	(2)	(3)	
(1)	0	10	9
(2)	4	0	999
(3)	5	999	0

 Matrix D1 
	(1)	(2)	(3)	
(1)	0	10	9
(2)	4	0	13
(3)	5	15	0
 Matrix D2 
	(1)	(2)	(3)	
(1)	0	10	9
(2)	4	0	13
(3)	5	15	0
 Matrix D3 
	(1)	(2)	(3)	
(1)	0	10	9
(2)	4	0	13
(3)	5	15	0

Path matrix: 
	(1)	(2)	(3)	
(1)	0	0	0
(2)	0	0	1
(3)	0	1	0

Enter the Source node:3
Enter the Destination node:2

The cost between 3 and 2 is 15 and the path is:3-1-2-

root@:~$ */




