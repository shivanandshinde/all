#include<stdio.h>
#include<math.h>
#define max 10

int nqueens(int k,int n);
int place(int k,int i);
int x[max],i,j,k,n;

void main()
{
int k,n;

printf("Enter the no. of Queens");
scanf("%d",&n);

k=1;
nqueens(k,n);	
	
}


int nqueens(int k,int n)
{
for(i=1;i<n;i++)
	{
	if(place(k,i))
	{
	x[k]=i;
	
	if(k==n)
		{
		for(i=1;i<=n;i++)
		 {
		  printf("%d \t",x[i]);
		 }
		 }
		else
		 {
		  nqueens(k+1,n);
		 }
	
	}
	}
}


int place(int k,int i)
{
for(j=1;j<k-1;j++)
	{
	if((x[j]==i)||(abs(x[j]-i)==abs(j-k)))
	{
	return 0;
	}
	return 1;
	}
}


