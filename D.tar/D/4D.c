
#include<stdio.h>
#include<math.h>
 
int a[20],count=1;
void nqueen(int row,int n); 

int main()
{
int n,i,j,k=1;
printf("\n\nEnter number of Queens:");
scanf("%d",&n);
nqueen(k,n);
return 0;
}
 
void print(int n)
{
int i,j;
printf("\n\nSolution %d:\n\n",count++);
 
for(i=1;i<=n;++i)
  printf("\t%d",i);
 
for(i=1;i<=n;++i)
{
  printf("\n\n%d",i);
  for(j=1;j<=n;++j) 
  {
   if(a[i]==j)
    printf("\tQ"); 
    //printf("\t%d",a[i]);
   else
    printf("\t-"); 
    //printf("\t%d",a[i]);
  }
}
printf("\n\n");
}
 
int place(int row,int column)
{
int i;
for(i=1;i<=row-1;++i)
{
 
if((a[i]==column)||(abs(a[i]-column)==abs(i-row)))
   return 0;
}
 
return 1; 
}
 
void nqueen(int row,int n)
{
int column,i;
for(column=1;column<=n;++column)
{
  printf("col: %d\n",column);	
  if(place(row,column))
  {
   a[row]=column; 
   for(i=0;i<n;i++)
    printf("%d ",a[i]);
   if(row==n) 
    print(n); 
   else 
    nqueen(row+1,n);
  }
}
}


/*

Output:
[Student@localhost ti081]$ gcc nqueen3.c
[Student@localhost ti081]$ ./a.out


Enter number of Queens:4


Solution 1:

	1	2	3	4

1	-	Q	-	-

2	-	-	-	Q

3	Q	-	-	-

4	-	-	Q	-



Solution 2:

	1	2	3	4

1	-	-	Q	-

2	Q	-	-	-

3	-	-	-	Q

4	-	Q	-	-

[Student@localhost ti081]$ 


*/
