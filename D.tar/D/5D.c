
#include<stdio.h>
#define M 30
int x[M],k;

void hamcycle(int G[M][M],int n, int k);
void issafe(int G[M][M], int n, int k);

int main()
{
	int i,j,G[M][M],n;
	printf("\n\tEnter the number of nodes:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			G[i][j]=0;
			x[i]=0;
		}
	}
	printf("\nEnter the adjacency matrix:\n");
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			scanf("%d",&G[i][j]);
		}
	}
	x[1]=1;
	printf("\n\tThe adjacency matrix is:\n");
	for(i=1;i<=n;i++)
	{
		printf("\n");
		for(j=1;j<=n;j++)
		{
			printf("%d\t",G[i][j]);
		}
	}
	printf("\n\tHamiltonian cycles is:\n");
	hamcycle(G,n,2);
	printf("\n");
	return 0;

}


void hamcycle(int G[M][M],int n,int k)
{
	int i;
	while(k!=0)
	{
		issafe(G,n,k);
		if(x[k]!=0)
		{
			if(k==n)
			{
				printf("\n");
				for(i=1;i<=n;i++)
				printf("%d-->",x[i]);
				printf("%d\n",x[1]);
			}
			else
			{
				k++;
			}
		}
		else
		k--;
	}
}


void issafe(int G[M][M], int n, int k)
{
	int j;
	while(1)
	{
		x[k]=(x[k]+1) % (n+1);
		if(x[k]==0)
		return;
		if(G[x[k-1]][x[k]]!=0)
		{
			for(j=1;j<=k-1;j++)
			{
				if(x[j]==x[k])
				break;
			}
			if(j==k)
			{
				if((k<n)||((k==n)&&(G[x[n]][x[1]])))
				return;
			}
		}
	}
}


/* 
	Output:

[student@localhost ~]$ gcc ham.c
[student@localhost ~]$ ./a.out

	Enter the number of nodes:4

Enter the adjacency matrix:
0 1 1 1 
1 0 1 1
1 1 0 1
1 1 1 0

	The adjacency matrix is:

0	1	1	1	
1	0	1	1	
1	1	0	1	
1	1	1	0	
	Hamiltonian cycles is:

1-->2-->3-->4-->1

1-->2-->4-->3-->1

1-->3-->2-->4-->1

1-->3-->4-->2-->1

1-->4-->2-->3-->1

1-->4-->3-->2-->1

[student@localhost ~]$ 
*/

