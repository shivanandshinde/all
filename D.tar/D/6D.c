#include<stdio.h>
#define N 5
int cost[N][N],temp[N][N],G[N-1],visited[N],set[N-1],min,sum,path[N],r=0;
int reduction(int temp[N][N])
{
    int i,j;
    sum=0;
    printf("\n");
    for(i=0;i<N;i++)
    {
        for(j=0; j<N; j++)
        {
            printf("\t%d",temp[i][j]);
        }
        printf("\n");
    }
    //Row Reduction
    for(i=0; i<N; i++)
    {
        min=999;
        for(j=0; j<N; j++)
        {
            if(temp[i][j] < min)
                min = temp[i][j];
           
        }
       
        if(min!=0 && min!=99)
        {
            for(j=0;j<N;j++)
            {
                if(i!=j && temp[i][j]!=99)
                {
                    temp[i][j] = temp[i][j]-min;
                   
                }
            }
            sum = sum+min;   
        }
    }
    /*printf("Row Reduction\n\t");
    for(i=0; i<N; i++)
    {
        for(j=0; j<N; j++)
        {
            printf("%d\t",temp[i][j]);
        }
        printf("\n");
    }*/
    //Column Redution
    for(i=0; i<N; i++)
    {
        min=999;
        for(j=0; j<N; j++)
        {
            if(temp[j][i] < min)
                min = temp[j][i];
        }
       
        if(min!=0 && min!=99)
        {
            for(j=0;j<N;j++)
            {
                if(i!=j && temp[j][i]!=99)
                {
                    temp[j][i] = temp[j][i]-min;
                   
                }
            }   
            sum = sum+min;
        }
    }
    printf("Column reduction\n\t");
    for(i=0; i<N; i++)
    {
        for(j=0; j<N; j++)
        {
            printf("%d\t",temp[i][j]);
        }
        printf("\n");
    }
    printf("Sum: %d",sum);
    return sum;
}
void copy(int temp[N][N],int cost[N][N])
{
    int i,j;
    for(i=0;i<N;i++)
    {
        for(j=0; j<N; j++)
        {
            temp[i][j] = cost[i][j];
        }
    }
}
void calc_cost(int set[], int index, int parent_cost)
{
    int i,j,k,ans;
    for(i=0; i<index; i++)
    {
        copy(temp,cost);
        for(j = 0; j <= r-1; j++)
        {
            for(k = 0; k < N; k++)
            {
                temp[path[j]][k] = 99;
                if(j != 0)
                    temp[k][path[j]] = 99;   
            }
        }
        for(k = 0; k < N; k++)
            temp[k][set[i]] = 99;
        temp[set[i]][0] = 99;
        printf("\n");
        /*for(k=0;k<N;k++)
        {
            for(j=0; j<N; j++)
            {
                printf("%d\t",temp[k][j]);
            }
            printf("\n");
        }*/
        ans = reduction(temp);
        G[i] = parent_cost + ans + cost[path[r-1]][set[i]];
        printf("path matrix is       %d->",G[i]);
    }
       
    parent_cost = find_min(G,index);
    printf("\nparent_cost=%d\n",parent_cost);
    index = 0;
    for(i = 0; i<N; i++)
    {
        if(visited[i] != 1)
        {
            set[index] = i;
            index++;
        }
    }
    if(index != 0)
        calc_cost(set,index,parent_cost);
   
}
int find_min(int G[], int index)
{
    int min,node,i;
    min = G[0];
    node = set[0];
    for(i = 1; i < index; i++)
    {
        if(min > G[i])
        {
            min = G[i];
            node = set[i];
        }
    }
    path[r] = node;
    r++;
    visited[node] = 1;
    return min;
}
int main()
{
    int i,j,index=0,parent_cost;
    for(i=0; i<N; i++)
    {
        for(j=0; j<N; j++)
        {
            if(i==j)
                cost[i][j]=99;
        }
    }
    printf("\nEnter the value of cost matrix\n");
    for(i=0; i<N; i++)
    {
        for(j=0; j<N; j++)
        {
            if(i!=j)
            {
                printf("Enter the value of cost[%d][%d]: ",i+1,j+1);
                scanf("%d",&cost[i][j]);
            }
        }
    }
    path[r] = 0;
    visited[0] = 1;
    r++;
    parent_cost = reduction(cost);
    printf("pc%d",parent_cost);
    for(i = 0; i<N; i++)
    {
        if(visited[i] != 1)
        {
            set[index] = i;
            index++;
        }
    }
    /*for(i=0;i<index;i++)
        printf("set: %d,",set[i]);*/
    calc_cost(set,index,parent_cost);
    for(i = 0; i<N; i++)
        printf("\t%d->",path[i]);
}

/*
Output

[student@localhost ~]$ gcc tsp.c
[student@localhost ~]$ ./a.out

Enter the value of cost matrix
Enter the value of cost[1][2]: 20
Enter the value of cost[1][3]: 30
Enter the value of cost[1][4]: 10
Enter the value of cost[1][5]: 11
Enter the value of cost[2][1]: 15
Enter the value of cost[2][3]: 16
Enter the value of cost[2][4]: 4
Enter the value of cost[2][5]: 2
Enter the value of cost[3][1]: 3
Enter the value of cost[3][2]: 5
Enter the value of cost[3][4]: 2
Enter the value of cost[3][5]: 4
Enter the value of cost[4][1]: 19
Enter the value of cost[4][2]: 6
Enter the value of cost[4][3]: 18
Enter the value of cost[4][5]: 3
Enter the value of cost[5][1]: 16
Enter the value of cost[5][2]: 4
Enter the value of cost[5][3]: 7
Enter the value of cost[5][4]: 16

	99	20	30	10	11
	15	99	16	4	2
	3	5	99	2	4
	19	6	18	99	3
	16	4	7	16	99
Column reduction
	99	10	17	0	1	
12	99	11	2	0	
0	3	99	0	2	
15	3	12	99	0	
11	0	0	12	99	
Sum: 25pc25

	99	99	99	99	99
	99	99	11	2	0
	0	99	99	0	2
	15	99	12	99	0
	11	99	0	12	99
Column reduction
	99	99	99	99	99	
99	99	11	2	0	
0	99	99	0	2	
15	99	12	99	0	
11	99	0	12	99	
Sum: 0path matrix is       35->

	99	99	99	99	99
	12	99	99	2	0
	99	3	99	0	2
	15	3	99	99	0
	11	0	99	12	99
Column reduction
	99	99	99	99	99	
1	99	99	2	0	
99	3	99	0	2	
4	3	99	99	0	
0	0	99	12	99	
Sum: 11path matrix is       53->

	99	99	99	99	99
	12	99	11	99	0
	0	3	99	99	2
	99	3	12	99	0
	11	0	0	99	99
Column reduction
	99	99	99	99	99	
12	99	11	99	0	
0	3	99	99	2	
99	3	12	99	0	
11	0	0	99	99	
Sum: 0path matrix is       25->

	99	99	99	99	99
	12	99	11	2	99
	0	3	99	0	99
	15	3	12	99	99
	99	0	0	12	99
Column reduction
	99	99	99	99	99	
10	99	9	0	99	
0	3	99	0	99	
12	0	9	99	99	
99	0	0	12	99	
Sum: 5path matrix is       31->
parent_cost=25


	99	99	99	99	99
	99	99	11	99	0
	0	99	99	99	2
	99	99	99	99	99
	11	99	0	99	99
Column reduction
	99	99	99	99	99	
99	99	11	99	0	
0	99	99	99	2	
99	99	99	99	99	
11	99	0	99	99	
Sum: 0path matrix is       28->

	99	99	99	99	99
	12	99	99	99	0
	99	3	99	99	2
	99	99	99	99	99
	11	0	99	99	99
Column reduction
	99	99	99	99	99	
1	99	99	99	0	
99	1	99	99	0	
99	99	99	99	99	
0	0	99	99	99	
Sum: 13path matrix is       50->

	99	99	99	99	99
	12	99	11	99	99
	0	3	99	99	99
	99	99	99	99	99
	99	0	0	99	99
Column reduction
	99	99	99	99	99	
1	99	0	99	99	
0	3	99	99	99	
99	99	99	99	99	
99	0	0	99	99	
Sum: 11path matrix is       36->
parent_cost=28


	99	99	99	99	99
	99	99	99	99	99
	99	99	99	99	2
	99	99	99	99	99
	11	99	99	99	99
Column reduction
	99	99	99	99	99	
99	99	99	99	99	
99	99	99	99	0	
99	99	99	99	99	
0	99	99	99	99	
Sum: 13path matrix is       52->

	99	99	99	99	99
	99	99	99	99	99
	0	99	99	99	99
	99	99	99	99	99
	99	99	0	99	99
Column reduction
	99	99	99	99	99	
99	99	99	99	99	
0	99	99	99	99	
99	99	99	99	99	
99	99	0	99	99	
Sum: 0path matrix is       28->
parent_cost=28


	99	99	99	99	99
	99	99	99	99	99
	99	99	99	99	99
	99	99	99	99	99
	99	99	99	99	99
Column reduction
	99	99	99	99	99	
99	99	99	99	99	
99	99	99	99	99	
99	99	99	99	99	
99	99	99	99	99	
Sum: 0path matrix is       28->
parent_cost=28
	0->	3->	1->	4->	2->[student@localhost ~]$
*/

